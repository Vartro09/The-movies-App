function toShow() {
    document.getElementById("sidebar").style.width = "20%";
    document.getElementById("mainContent").style.marginLeft = "20%";
    document.getElementById("openMain").style.display = "none";
    document.getElementById("close").style.display = "inline";
};

function hide() {
    document.getElementById("sidebar").style.width = "0";
    document.getElementById("mainContent").style.marginLeft = "0";
    document.getElementById("openMain").style.display = "inline";
    document.getElementById("close").style.display = "none";
};