var btnOpenPopup = document.getElementById('btn-open-popup'),
    btnOpenPopup2 = document.getElementById('btn-open-popup2'),
    btnOpenPopup3 = document.getElementById('btn-open-popup3'),
    btnOpenPopup4 = document.getElementById('btn-open-popup4'),
    btnOpenPopup5 = document.getElementById('btn-open-popup5'),
    btnOpenPopup6 = document.getElementById('btn-open-popup6'),
    btnOpenPopup7 = document.getElementById('btn-open-popup7'),
    btnOpenPopup8 = document.getElementById('btn-open-popup8'),
    btnOpenPopup9 = document.getElementById('btn-open-popup9'),
    btnOpenPopup10 = document.getElementById('btn-open-popup10'),
	overlay = document.getElementById('overlay'),
    overlay2 = document.getElementById('overlay2'),
    overlay3 = document.getElementById('overlay3'),
    overlay4 = document.getElementById('overlay4'),
    overlay5 = document.getElementById('overlay5'),
    overlay6 = document.getElementById('overlay6'),
    overlay7 = document.getElementById('overlay7'),
    overlay8 = document.getElementById('overlay8'),
    overlay9 = document.getElementById('overlay9'),
    overlay10 = document.getElementById('overlay10'),
	popup = document.getElementById('popup'),
    popup2 = document.getElementById('popup2'),
    popup3 = document.getElementById('popup3'),
    popup4 = document.getElementById('popup4'),
    popup5 = document.getElementById('popup5'),
    popup6 = document.getElementById('popup6'),
    popup7 = document.getElementById('popup7'),
    popup8 = document.getElementById('popup8'),
    popup9 = document.getElementById('popup9'),
    popup10 = document.getElementById('popup10'),
	btnClosePopup = document.getElementById('btn-close-popup'),
    btnClosePopup2 = document.getElementById('btn-close-popup2'),
    btnClosePopup3 = document.getElementById('btn-close-popup3'),
    btnClosePopup4 = document.getElementById('btn-close-popup4'),
    btnClosePopup5 = document.getElementById('btn-close-popup5'),
    btnClosePopup6 = document.getElementById('btn-close-popup6'),
    btnClosePopup7 = document.getElementById('btn-close-popup7'),
    btnClosePopup8 = document.getElementById('btn-close-popup8'),
    btnClosePopup9 = document.getElementById('btn-close-popup9'),
    btnClosePopup10 = document.getElementById('btn-close-popup10');


btnOpenPopup.addEventListener('click', function(){
	overlay.classList.add('active');
	popup.classList.add('active');
});

btnOpenPopup2.addEventListener('click', function(){
	overlay2.classList.add('active');
	popup2.classList.add('active');
});
btnOpenPopup3.addEventListener('click', function(){
	overlay3.classList.add('active');
	popup3.classList.add('active');
});
btnOpenPopup4.addEventListener('click', function(){
	overlay4.classList.add('active');
	popup4.classList.add('active');
});
btnOpenPopup5.addEventListener('click', function(){
	overlay5.classList.add('active');
	popup5.classList.add('active');
});
btnOpenPopup6.addEventListener('click', function(){
	overlay6.classList.add('active');
	popup6.classList.add('active');
});
btnOpenPopup7.addEventListener('click', function(){
	overlay7.classList.add('active');
	popup7.classList.add('active');
});
btnOpenPopup8.addEventListener('click', function(){
	overlay8.classList.add('active');
	popup8.classList.add('active');
});
btnOpenPopup9.addEventListener('click', function(){
	overlay9.classList.add('active');
	popup9.classList.add('active');
});
btnOpenPopup10.addEventListener('click', function(){
	overlay10.classList.add('active');
	popup10.classList.add('active');
});

btnClosePopup.addEventListener('click', function(e){
	e.preventDefault();
	overlay.classList.remove('active');
	popup.classList.remove('active');
});
btnClosePopup2.addEventListener('click', function(e){
	e.preventDefault();
	overlay2.classList.remove('active');
	popup2.classList.remove('active');
});
btnClosePopup3.addEventListener('click', function(e){
	e.preventDefault();
	overlay3.classList.remove('active');
	popup3.classList.remove('active');
});
btnClosePopup3.addEventListener('click', function(e){
	e.preventDefault();
	overlay3.classList.remove('active');
	popup3.classList.remove('active');
});
btnClosePopup4.addEventListener('click', function(e){
	e.preventDefault();
	overlay4.classList.remove('active');
	popup4.classList.remove('active');
});
btnClosePopup5.addEventListener('click', function(e){
	e.preventDefault();
	overlay5.classList.remove('active');
	popup5.classList.remove('active');
});
btnClosePopup6.addEventListener('click', function(e){
	e.preventDefault();
	overlay6.classList.remove('active');
	popup6.classList.remove('active');
});
btnClosePopup7.addEventListener('click', function(e){
	e.preventDefault();
	overlay7.classList.remove('active');
	popup7.classList.remove('active');
});
btnClosePopup8.addEventListener('click', function(e){
	e.preventDefault();
	overlay8.classList.remove('active');
	popup8.classList.remove('active');
});
btnClosePopup9.addEventListener('click', function(e){
	e.preventDefault();
	overlay9.classList.remove('active');
	popup9.classList.remove('active');
});
btnClosePopup10.addEventListener('click', function(e){
	e.preventDefault();
	overlay10.classList.remove('active');
	popup10.classList.remove('active');
});




